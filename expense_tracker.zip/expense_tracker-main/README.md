# Expense Tracker Application
________

## Description

**The problem:** UPI and other payment solutions becoming more and more relevant day by day, we tend to spend money quickly. So an internet and localstorage based solution to keep a track of your income and expense.

**Technologies used:** HTML, CSS and Javascript

## Prerequisits

A computer with a working internet connection

## License

MIT Open License.

## Contributing

Contribute to this project by looking at the [issues](https://github.com/AyushmanBilasThakur/expense_tracker/issues)

## Contact 

ayushmanbilasthakur@gmail.com
